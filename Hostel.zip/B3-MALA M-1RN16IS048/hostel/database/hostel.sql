-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2019 at 01:56 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `str1` ()  select name,roomno,totalfee,paymentdate
from payment
where totalfee>50000$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `str2` ()  select name,regno,gender,contactno,course,roomno
from registration
where corresState="Karnataka" AND pmnatetState="Karnataka"$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `str3` ()  select id,room_no,fees
from rooms
where seater=2$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `reg_date`, `updation_date`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', '2018-11-04 20:31:45', '2018-11-17');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_sn` varchar(255) NOT NULL,
  `course_fn` varchar(255) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_sn`, `course_fn`, `posting_date`) VALUES
(1, 'BT10992', 'B.Tech', 'Bachelor  of Technology', '2018-11-11 19:31:42'),
(2, 'BCOM14', 'B.Com', 'Bachelor Of commerce ', '2018-11-11 19:32:46'),
(3, 'BSC1234', 'BSC', 'Bachelor  of Science', '2018-11-11 19:33:23'),
(4, 'BC36356', 'BCA', 'Bachelor Of Computer Application', '2018-11-11 19:34:18'),
(5, 'MCA5658', 'MCA', 'Master of Computer Application', '2018-11-11 19:34:40'),
(6, 'MBA7512', 'MBA', 'Master of Business Administration', '2018-11-11 19:34:59'),
(7, 'BE76578', 'BE', 'Bachelor of Engineering', '2018-11-11 19:35:19');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentid` int(11) NOT NULL,
  `roomno` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `totalfee` int(20) NOT NULL,
  `paymentdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`paymentid`, `roomno`, `name`, `emailid`, `totalfee`, `paymentdate`) VALUES
(1, 101, 'Anusha', 'anusha@gmail.com', 48000, '2018-11-24'),
(2, 200, 'Keerthana', 'keerthanav@gmail.com', 14000, '2018-11-26'),
(3, 101, 'Uday ', 'uday@gmail.com', 82000, '2018-11-26'),
(4, 112, 'Brunda', 'bru@gmail.com', 28000, '2018-12-06');

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `paytri` AFTER INSERT ON `payment` FOR EACH ROW insert into paymentlog values(null,new.emailid,new.roomno,new.totalfee,now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `paymentlog`
--

CREATE TABLE `paymentlog` (
  `id` int(11) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `roomno` int(11) NOT NULL,
  `totalfee` int(20) NOT NULL,
  `paymentdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymentlog`
--

INSERT INTO `paymentlog` (`id`, `emailid`, `roomno`, `totalfee`, `paymentdate`) VALUES
(1, 'anusha@gmail.com', 101, 48000, '2018-11-24'),
(2, 'keerthanav@gmail.com', 200, 14000, '2018-11-26'),
(3, 'uday@gmail.com', 101, 82000, '2018-11-26'),
(4, 'bru@gmail.com', 112, 28000, '2018-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `roomno` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `feespm` int(11) NOT NULL,
  `foodstatus` int(11) NOT NULL,
  `stayfrom` date NOT NULL,
  `duration` int(11) NOT NULL,
  `course` varchar(500) NOT NULL,
  `regno` varchar(25) NOT NULL,
  `name` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `guardianName` varchar(500) NOT NULL,
  `guardianRelation` varchar(500) NOT NULL,
  `guardianContactno` bigint(11) NOT NULL,
  `corresAddress` varchar(500) NOT NULL,
  `corresState` varchar(500) NOT NULL,
  `corresPincode` int(11) NOT NULL,
  `pmntAddress` varchar(500) NOT NULL,
  `pmnatetState` varchar(500) NOT NULL,
  `pmntPincode` int(11) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `roomno`, `seater`, `feespm`, `foodstatus`, `stayfrom`, `duration`, `course`, `regno`, `name`, `gender`, `contactno`, `emailid`, `guardianName`, `guardianRelation`, `guardianContactno`, `corresAddress`, `corresState`, `corresPincode`, `pmntAddress`, `pmnatetState`, `pmntPincode`, `postingDate`, `updationDate`) VALUES
(9, 101, 2, 8000, 0, '2018-11-22', 6, 'Bachelor  of Technology', '1597886', 'Anusha', 'female', 7349489469, 'anusha@gmail.com', 'Bhanu', 'sister', 9379261560, 'kundapura', 'Karnataka', 580096, 'kundapura', 'Karnataka', 580096, '2018-11-22 08:37:47', ''),
(10, 101, 2, 8000, 1, '2018-11-22', 10, 'Bachelor Of commerce ', '1789659', 'Uday', 'male', 9901024239, 'uday@gmail.com', 'ram', 'brother', 6665534998, 'palace road', 'Karnataka', 570089, 'palace road', 'Karnataka', 570089, '2018-11-22 08:43:58', ''),
(11, 200, 3, 6000, 1, '2018-11-22', 2, 'Bachelor of Engineering', '1597234', 'Keerthana', 'female', 7760449691, 'keerthanav@gmail.com', 'Vijay', 'father', 6786578098, 'mg road', 'Delhi ', 890076, 'mg road', 'Delhi ', 890076, '2018-11-22 14:28:26', ''),
(12, 112, 4, 4000, 0, '2018-11-28', 7, 'Bachelor  of Science', '12980908', 'Brunda', 'female', 9901024239, 'bru@gmail.com', 'anu', 'mother', 9379261560, 'madikeri', 'Karnataka', 9978682, 'madikeri', 'Karnataka', 9978682, '2018-11-28 14:25:23', ''),
(13, 112, 4, 4000, 1, '2018-12-06', 8, 'Master of Business Administration', '1547845', 'Goutham', 'male', 9978682123, 'goutham@gmail.com', 'lakshmi', 'mother', 6665534998, 'jayanagar bangalore', 'Karnataka', 560078, 'jayanagar bangalore', 'Karnataka', 560078, '2018-12-06 05:57:25', '');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `fees` int(11) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `seater`, `room_no`, `fees`, `posting_date`) VALUES
(1, 2, 100, 8000, '2018-11-11 22:45:43'),
(2, 2, 101, 8000, '2018-11-12 01:30:47'),
(3, 3, 200, 6000, '2018-11-12 01:30:58'),
(4, 4, 112, 4000, '2018-11-12 01:31:07'),
(5, 5, 132, 2000, '2018-11-12 01:31:15');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `State` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `State`) VALUES
(1, 'Andhra Pradesh'),
(2, 'Assam'),
(3, 'Bihar'),
(4, 'Chandigarh'),
(5, 'Chhattisgarh'),
(6, 'Delhi '),
(7, 'Goa'),
(8, 'Gujarat'),
(9, 'Haryana'),
(10, 'Jammu and Kashmir'),
(11, 'Jharkhand'),
(12, 'Karnataka'),
(13, 'Kerala'),
(14, 'Madhya Pradesh'),
(15, 'Maharashtra'),
(16, 'Odisha'),
(17, 'Punjab'),
(18, 'Rajasthan'),
(19, 'Tamil Nadu'),
(20, 'Telangana'),
(21, 'Uttar Pradesh'),
(22, 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userId`, `userEmail`, `loginTime`) VALUES
(7, 11, 'anusha@gmail.com', '2018-11-22 08:36:23'),
(8, 12, 'uday@gmail.com', '2018-11-22 09:13:19'),
(9, 11, 'anusha@gmail.com', '2018-11-22 09:25:28'),
(10, 12, 'uday@gmail.com', '2018-11-22 09:43:12'),
(11, 13, 'keerthanav@gmail.com', '2018-11-22 14:26:46'),
(12, 11, 'anusha@gmail.com', '2018-11-24 03:50:35'),
(13, 11, 'anusha@gmail.com', '2018-11-24 04:55:43'),
(14, 11, 'anusha@gmail.com', '2018-11-24 05:32:40'),
(15, 11, 'anusha@gmail.com', '2018-11-24 05:44:43'),
(16, 12, 'uday@gmail.com', '2018-11-24 05:48:14'),
(17, 11, 'anusha@gmail.com', '2018-11-24 05:48:54'),
(18, 11, 'anusha@gmail.com', '2018-11-24 05:55:27'),
(19, 11, 'anusha@gmail.com', '2018-11-25 17:18:35'),
(20, 13, 'keerthanav@gmail.com', '2018-11-25 17:21:17'),
(21, 13, 'keerthanav@gmail.com', '2018-11-26 03:22:58'),
(22, 11, 'anusha@gmail.com', '2018-11-26 03:55:38'),
(23, 12, 'uday@gmail.com', '2018-11-26 03:56:20'),
(24, 13, 'keerthanav@gmail.com', '2018-11-26 04:16:45'),
(25, 12, 'uday@gmail.com', '2018-11-26 05:32:22'),
(26, 12, 'uday@gmail.com', '2018-11-26 05:36:55'),
(27, 11, 'anusha@gmail.com', '2018-11-26 05:44:32'),
(28, 13, 'keerthanav@gmail.com', '2018-11-26 06:15:43'),
(29, 11, 'anusha@gmail.com', '2018-11-28 13:49:04'),
(30, 14, 'bru@gmail.com', '2018-11-28 14:26:14'),
(31, 13, 'keerthanav@gmail.com', '2018-11-30 00:21:18'),
(32, 14, 'bru@gmail.com', '2018-11-30 02:20:38'),
(33, 15, 'goutham@gmail.com', '2018-11-30 15:05:26'),
(34, 15, 'goutham@gmail.com', '2018-11-30 15:06:43'),
(35, 13, 'keerthanav@gmail.com', '2018-12-04 16:07:00'),
(36, 11, 'anusha@gmail.com', '2018-12-04 16:14:20'),
(37, 14, 'bru@gmail.com', '2018-12-06 05:42:41'),
(38, 15, 'goutham@gmail.com', '2018-12-06 05:44:07'),
(39, 15, 'goutham@gmail.com', '2018-12-06 05:56:33'),
(40, 14, 'bru@gmail.com', '2018-12-06 06:25:33');

-- --------------------------------------------------------

--
-- Table structure for table `userregistration`
--

CREATE TABLE `userregistration` (
  `id` int(11) NOT NULL,
  `regNo` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `contactNo` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(45) NOT NULL,
  `passUdateDate` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregistration`
--

INSERT INTO `userregistration` (`id`, `regNo`, `name`, `gender`, `contactNo`, `email`, `password`, `regDate`, `updationDate`, `passUdateDate`) VALUES
(11, '1597886', 'Anusha', 'female', 9980184523, 'anusha@gmail.com', 'anusha', '2018-11-22 08:35:08', '22-11-2018 02:56:24', ''),
(12, '1789659', 'Uday', 'male', 9901024239, 'uday@gmail.com', 'uday', '2018-11-22 08:41:34', '', ''),
(13, '1597234', 'Keerthana', 'female', 7760449691, 'keerthanav@gmail.com', 'keerthanav', '2018-11-22 09:33:15', '', '26-11-2018 08:54:08'),
(14, '12980908', 'Brunda', 'female', 9901024239, 'bru@gmail.com', 'brunda', '2018-11-28 14:25:23', '', ''),
(15, '1547845', 'Goutham', 'male', 9978682123, 'goutham@gmail.com', 'goutham', '2018-11-30 15:05:26', '', '');

--
-- Triggers `userregistration`
--
DELIMITER $$
CREATE TRIGGER `usetri` AFTER INSERT ON `userregistration` FOR EACH ROW INSERT INTO userlog VALUES(null,new.id,new.email,now())
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_sn` (`course_sn`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentid`);

--
-- Indexes for table `paymentlog`
--
ALTER TABLE `paymentlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregistration`
--
ALTER TABLE `userregistration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `paymentlog`
--
ALTER TABLE `paymentlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `userregistration`
--
ALTER TABLE `userregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
